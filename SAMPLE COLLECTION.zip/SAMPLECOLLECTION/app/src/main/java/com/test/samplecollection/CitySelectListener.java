package com.test.samplecollection;
public interface CitySelectListener {
    void onCitySelected(String selectedCity);
}

